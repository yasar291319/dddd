sudo pip install scapy
sudo pip install fake-useragent